-- Dedicated Odds Collector database only. Never run on football-data-center-db.
BEGIN;
CREATE TABLE IF NOT EXISTS odds_api_calls (
 id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
 reserved_at TIMESTAMPTZ NOT NULL DEFAULT now(),
 provider TEXT NOT NULL,
 status TEXT NOT NULL DEFAULT 'reserved',
 CHECK (status IN ('reserved','succeeded','failed'))
);
CREATE TABLE IF NOT EXISTS odds_snapshots (
 id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
 provider TEXT NOT NULL,
 observed_at TIMESTAMPTZ NOT NULL,
 event_id TEXT NOT NULL,
 payload_sha256 CHAR(64) NOT NULL,
 raw_json JSONB NOT NULL,
 UNIQUE(provider, observed_at, event_id, payload_sha256)
);
CREATE INDEX IF NOT EXISTS odds_snapshots_event_idx ON odds_snapshots(provider,event_id,observed_at DESC);
CREATE TABLE IF NOT EXISTS odds_market_observations (
 id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
 snapshot_id BIGINT NOT NULL REFERENCES odds_snapshots(id) ON DELETE CASCADE,
 bookmaker_id TEXT NOT NULL,
 market_id TEXT NOT NULL,
 player_id TEXT,
 selection_id TEXT NOT NULL,
 decimal_odds NUMERIC(12,5),
 market_period TEXT,
 outcome_status TEXT NOT NULL DEFAULT 'unsettled',
 CHECK (decimal_odds IS NULL OR decimal_odds > 1),
 CHECK (outcome_status IN ('unsettled','won','lost','void','unknown')),
 UNIQUE(snapshot_id,bookmaker_id,market_id,selection_id)
);
COMMIT;
