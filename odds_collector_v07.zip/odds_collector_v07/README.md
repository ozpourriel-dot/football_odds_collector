# Odds Collector v0.6 — classification préliminaire des marchés

Ajoute `market_classifier.py`, `market_report.py`, `test_markets.py` à la v0.5.

Marchés ciblés : buteur 1+, 2+, 3+, passeur 1+, buteur première mi-temps. Les catégories ne sont détectées que par des libellés explicites. Un marché ambigu est signalé `needs_review=true` ; aucune cote n'est inventée. Le classificateur ne sait pas encore traiter de manière fiable les identifiants spécifiques SportsGameOdds, les joueurs, les bookmakers ni les lignes de prix. Une vraie réponse fournisseur est indispensable pour valider ces champs.

## Tests
`python -m unittest discover -v`

## Inspection sans appel API
`python collector.py --fixture example_response.json --db test.sqlite`
`python market_report.py --db test.sqlite --csv markets.csv`

## Limites de déploiement
Ne pas déployer en production : stockage SQLite non persistant sur Render, pas d'intégration réelle vérifiée, pas de secret configuré, aucune collecte active. Aucun service Render ni base existante ne sont modifiés.

## v0.7 — rapport de couverture hors ligne
`python coverage_report.py --db test.sqlite --csv coverage.csv`
Rapport des 5 marchés demandés, sans confondre « non observé » et « non proposé par le fournisseur ». La présence d'un libellé ne prouve pas l'existence d'une cote exploitable : extraction bookmaker/joueur/prix encore à valider sur une vraie réponse. Tests supplémentaires de seuils 1+/2+/3+, refus des marchés d'équipe, under et libellés contradictoires.

### Étape utilisateur nécessaire (sans communiquer la clé dans ChatGPT)
Configurer `SPORTSGAMEODDS_API_KEY` comme variable d'environnement secrète **sur un service de test indépendant autorisé**. Ne pas la placer dans un dépôt public ni dans une capture. Ne pas déployer ce prototype sur le service Football Data Center existant. Aucun déploiement ou appel API réel n'est effectué par cette archive.
